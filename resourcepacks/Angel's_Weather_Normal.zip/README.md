# Angel's Weather

Thank you for exploring Angel's Weather! This resource pack has been meticulously designed to enhance your Minecraft experience with immersive sounds, refined textures, and subtle PBR (Physically Based Rendering) support. 

## Features
- **Dynamic Weather Enhancements**: Custom snow, rain and thunder for a more realistic and atmospheric experience.
- **Optimized Textures**: Crafted with attention to detail to balance visual quality and performance to some extent for low performance devices.
- **Shader-Compatible Enhancements**: Supports PBR properties for shaders that allow reflective and dynamic visual effects.

## Technical Information
- **Minecraft Compatibility**: Works with Minecraft versions 1.14 and higher.
- **Mod Compatibility**: Fully compatible with OptiFine, IRIS, Complementary, EMF, and ETF mods.
- **PBR Support**: Designed to integrate with shaders that support Physically Based Rendering (PBR).

## Credits
- **Audio**: Professionally recorded and designed for an immersive ambient experience.
- **Textures**: Carefully crafted for seamless integration with a variety of mods, shaders and resourcepacks.

## Feedback & Support
Your feedback is invaluable! If you have suggestions, encounter issues, or simply want to share your thoughts, feel free to join my Discord server:  
https://discord.gg/t7JJPyxJ6k

Thank you for your interest and support. I hope you enjoy this resource pack and all it brings to your Minecraft adventures!

For support and donations visit my Ko-Fi:
https://ko-fi.com/liminalangel